﻿using System;
using Raylib_cs;
using System.Numerics;
using System.Diagnostics;

namespace Raytracer
{
    class Program
    {
        public static int width = 320, height = 180;
        public static float ratio = (float)height / width;
        public static float nearPlane = 1f, farPlane = 10f;

        public static float precision = 0.01f;

        public static float average = 0f;

        public static Vector3 sun = new Vector3(-1, -1, 0);

        public static Sphere[] spheres = new Sphere[]
        {
            new Sphere
            {
                posistion = new Vector3(11.5f, 0f, 0.5f),
                color = Color.RED,
                radius = 1f,
                shader = Shaders.Basic.shader
            }
            
        };

        static void Main(string[] args)
        {
            Raylib.SetTraceLogLevel(TraceLogLevel.LOG_NONE);
            Raylib.InitWindow(width, height, "Raymarcher");
            Image image = Raylib.GenImageColor(width, height, Color.BLANK);
            
            Console.WriteLine("Started!");

            while (!Raylib.WindowShouldClose())
            {
                float mspf = Raytrace(ref image);
                //average += mspf;
                //average *= 0.5f;
                average = MathF.Max(average, 1000f / mspf);

                Texture2D texture2D = Raylib.LoadTextureFromImage(image);

                Raylib.BeginDrawing();
                Raylib.ClearBackground(Color.BLACK);

                Raylib.DrawTexture(texture2D, 0, 0, Color.WHITE);

                //Raylib.DrawText("MSPF: " + mspf, 5, 5, 10, Color.GREEN);
                Raylib.DrawText("HIGH: " + average, 5, 5, 10, Color.GREEN);

                Raylib.EndDrawing();
                Raylib.UnloadTexture(texture2D);

                spheres[0].posistion.X = MathF.Sin((float)Raylib.GetTime()) + 3f;
            }
        }

        static long Raytrace(ref Image image)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Raylib.ImageClearBackground(ref image, Color.RED);

            for (int u = 0; u < width; u++)
            {
                for (int v = 0; v < height; v++)
                {
                    Raylib.ImageDrawPixel(ref image, u, v, RenderPixel(u, v));
                }
            }
            stopwatch.Stop();
            return stopwatch.ElapsedMilliseconds;
            //Console.WriteLine("Frame took " + stopwatch.ElapsedMilliseconds + " ms to complete");
        }

        static Color RenderPixel(int u, int v)
        {
            
            float distanceTraveled = 0;

            Vector2 screenCoord = new Vector2(u / (float)width / ratio, v / (float)height) - Vector2.One * 0.5f;
            Vector3 worldCoord = new Vector3(nearPlane, screenCoord.Y, screenCoord.X);

            Vector3 direction = worldCoord / worldCoord.Length();

            while(distanceTraveled <= farPlane)
            {
                Vector3 pos = worldCoord + (direction * distanceTraveled);
                float lowestDst = float.MaxValue;

                for (int o = 0; o < spheres.Length; o++)
                {
                    float dst = spheres[o].DistanceToSurface(pos);
                    if (dst <= precision)
                    {
                        return spheres[o].shader.Fragment(new FragmentInput { position = pos, ray = direction, sphere = spheres[o] });
                    }

                    lowestDst = MathF.Min(lowestDst, dst);
                }

                distanceTraveled += lowestDst;
            }

            return Color.BLUE;
        }
    }

    public class Sphere
    {
        public float radius;
        public Color color;
        public Vector3 posistion;
        public IShader shader;

        public bool IsInside(Vector3 pos)
        {
            return (posistion - pos).Length() < radius;
        }

        public float DistanceToSurface(Vector3 pos)
        {
            return (posistion - pos).Length() - radius;
        }

        public Vector3 CalculateNormal(Vector3 pos)
        {
            Vector3 diffVec = posistion - pos;
            float len = diffVec.Length();
            Vector3 n = diffVec / len;
            return n;
        }
    }
}
